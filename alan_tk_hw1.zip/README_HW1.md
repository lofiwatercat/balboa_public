Source code is in src directory
Renderings are in the output directory
The custom scene's json is in the scene/hw1 directory
